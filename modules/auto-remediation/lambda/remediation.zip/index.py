import json
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def handler(event, context):
    logger.info(f"Received event: {json.dumps(event)}")
    detail       = event.get("detail", {})
    finding_type = detail.get("type", "")
    severity     = detail.get("severity", 0)
    logger.info(f"Finding: {finding_type} | Severity: {severity}")
    if severity >= 7:
        logger.info("HIGH severity - initiating auto-remediation")
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Auto-remediation triggered",
                "finding_type": finding_type,
                "severity": severity
            })
        }
    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Below remediation threshold - logged only"})
    }
